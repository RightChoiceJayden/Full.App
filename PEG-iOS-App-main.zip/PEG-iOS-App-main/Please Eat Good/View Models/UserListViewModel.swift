//
//  UserListViewModel.swift
//  iTrayne
//
//  Created by Christopher on 9/27/20.
//  Copyright © 2020 iTrayne LLC. All rights reserved.
//

import Foundation
import SwiftUI

class UserListViewModel:ObservableObject {
    //private var profileService:AppService<Profile> = AppService<Profile>(collectionName: "Profiles")
    
    init() {
        
    }
    
}
